let appState = {
  users: [],
  demographics: [],
  immunization: [],
  medication_allergies: [],
  isLoggedIn: false,
  authToken: "",
  globalmessage: "",
  role: "",
  loggedUserInfo: {},
  physicians: [],
  patients: [],
  userDetails: {},
};

export default appState;
