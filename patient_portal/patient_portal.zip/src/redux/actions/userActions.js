export const GET_USERS = "GET_USERS";
export const ADD_DEMOGRAPHICS = "ADD_DEMOGRAPHICS";
export const ADD_IMMUNIZATION = "ADD_IMMUNIZATION";
export const ADD_MEDICATIONANDALLERGIES = "ADD_MEDICATIONANDALLERGIES";

export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";
export const REGISTER = "REGISTER";

export const PHYSICIANS = "PHYSICIANS";
export const PATIENTS = "PATIENTS";
export const ADD_USER = "ADD_USER";
export const GET_ALL_USERS = "GET_ALL_USERS";
export const UPDATE_USER = "UPDATE_USER";
export const GET_USER = "GET_USER";
