export {default as PersonIcon} from '@material-ui/icons/Person';
export {default as DeleteIcon} from '@material-ui/icons/Delete';
export {default as SearchIcon} from '@material-ui/icons/Search';
export {default as MailIcon} from '@material-ui/icons/Mail';
export {default as NotificationsIcon} from '@material-ui/icons/Notifications';
export {default as HomeIcon} from '@material-ui/icons/Home';
export {default as AccessibilityIcon} from '@material-ui/icons/Accessibility';
export {default as ArchiveIcon} from '@material-ui/icons/Archive';
export {default as DashboardIcon} from '@material-ui/icons/Dashboard';
export {default as GroupIcon} from '@material-ui/icons/Group';
export {default as ListAltIcon} from '@material-ui/icons/ListAlt';
export {default as PermContactCalendarIcon} from '@material-ui/icons/PermContactCalendar';
export {default as ReceiptIcon} from '@material-ui/icons/Receipt';
export {default as DetailsIcon} from '@material-ui/icons/Details';
export {default as ContactPhoneIcon} from '@material-ui/icons/ContactPhone';


