export default [
  {
    title: "",
    urls: "https://www.kailashhealthcare.com/healthpackagesnew/images/slider-1.png",
  },
  {
    title: "",
    urls: "https://www.maggohospital.com/wp-content/uploads/2019/10/banner1.jpg",
  },
  {
    title: "",

    urls: "https://www.kailashhealthcare.com/healthpackagesnew/images/slider-1.png",
  },
  {
    title: "",

    urls: "https://www.maggohospital.com/wp-content/uploads/2019/10/banner1.jpg",
  },
  {
    title: "",

    urls: "https://www.springvalleyhospital.com/sites/springvalleyhospital.com/files/styles/art_directed_banner__desktop_1700x605/public/AC-recovery_herobanner_6_1700.jpg?itok=ZXUQXtiJ",
  },
  {
    title: "",

    urls: "https://kimsthospital.in/images/abt-bnr07.jpg",
  },
  {
    title: "",

    urls: "https://kims-app-server.s3.ap-south-1.amazonaws.com/images/blogs/endoscopy-in-the-treatment-of-pancreatic-diseases_1615443806.png",
  },
];
