import React from "react";
const Patient_dashboard = () => {
  return (
    <>
     
    </>
  );
};

export default Patient_dashboard;
