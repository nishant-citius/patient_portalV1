import React, { Component } from 'react';

class ForgotUserName extends React.Component {
    render() { 
        return <div>
            forgot username
        </div>;
    }
}
 
export default ForgotUserName;