import React, { Component } from 'react';

class ForgotPassword extends React.Component {
    render() { 
        return <div>forgot password page</div>;
    }
}
 
export default ForgotPassword;